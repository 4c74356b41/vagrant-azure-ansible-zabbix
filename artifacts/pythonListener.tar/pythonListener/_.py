#! /usr/bin/env python

import redis
import threading
from time import sleep
import logging
import os

logging.basicConfig(filename='pubsub.log',level=1)

class Listener(threading.Thread):
    def __init__(self, r, channels):
        threading.Thread.__init__(self)
        self.redis = r
        self.pubsub = self.redis.pubsub()
        self.pubsub.subscribe(channels)

    def work(self, item):
        logging.info('Processed: %s from Channel: %s', item['data'], item['channel'])
        vint = float(int(item['data']))
        print vint
        sleep(vint)

    def run(self):
        for item in self.pubsub.listen():
            if item['data'] == 123:
                self.pubsub.unsubscribe()
                print(self, "unsubscribed and finished")
                break
            else:
                self.work(item)

if __name__ == "__main__":
    host = os.getenv('redishost', '52.166.242.90')
    channel = os.getenv('redischannel', 'SimplePubSubCHANNEL')
    r = redis.Redis(host=host)
    client = Listener(r, [channel])
    client.start()