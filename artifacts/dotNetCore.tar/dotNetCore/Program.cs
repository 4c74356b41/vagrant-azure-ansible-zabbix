﻿using System;
using ServiceStack.Redis;
using System.Diagnostics;
using System.Threading;
using System.IO;

namespace ConsoleApp1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var message = args[0];
            var runme = new SimplePubSub();
            runme.Publish_messages(message);
        }

        public class SimplePubSub
        {
            const string serveraddress = "localhost";
            const string ChannelName = "SimplePubSubCHANNEL";
            const int PublishMessageCount = 0;

            public void Publish_messages(string message)
            {

                using (var redisConsumer = new RedisClient(serveraddress))
                using (var subscription = redisConsumer.CreateSubscription())
                {
                    subscription.OnSubscribe = channel =>
                    {
                        Debug.WriteLine(String.Format("Subscribed to '{0}'", channel));
                    };
                    subscription.OnUnSubscribe = channel =>
                    {
                        Debug.WriteLine(String.Format("UnSubscribed from '{0}'", channel));
                    };

                    ThreadPool.QueueUserWorkItem(x =>
                    {
                        Thread.Sleep(2000);
                        Debug.WriteLine("Begin publishing messages...");

                        using (var redisPublisher = new RedisClient(serveraddress))
                        {
                            for (var i = 1; i >= PublishMessageCount; i++)
                            {
                                Thread.Sleep(200);
                                using (StreamWriter w = File.AppendText("pubsub.log"))
                                {
                                    Log(message, ChannelName, w);
                                }
                                Console.WriteLine(String.Format("Publishing '{0}' to '{1}'", message, ChannelName));
                                Debug.WriteLine(String.Format("Publishing '{0}' to '{1}'", message, ChannelName));
                                redisPublisher.PublishMessage(ChannelName, message);
                            }
                        }
                    });

                    Console.WriteLine(String.Format("Started On '{0}'", ChannelName));
                    subscription.SubscribeToChannels(ChannelName); //blocking
                }

                Debug.WriteLine("EOF");

            }

            public static void Log(string logChannel, string logMessage, TextWriter w)
            {
                w.Write("{0}||| Channel: {1}; Message: {2}\r\n", DateTime.Now.ToString(), logChannel, logMessage);
            }
        }
    }
}
